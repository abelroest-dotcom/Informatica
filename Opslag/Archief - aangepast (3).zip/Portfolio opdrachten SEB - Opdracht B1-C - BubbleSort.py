cijfers = []

for i in range(3):
    cijfer = float(input("Geef een cijfer: "))
    cijfers.append(cijfer)

if cijfers[0] > cijfers[1]:
    cijfers[0], cijfers[1] = cijfers[1], cijfers[0]

if cijfers[1] > cijfers[2]:
    cijfers[1], cijfers[2] = cijfers[2], cijfers[1]
    
if cijfers[0] > cijfers[1]:
    cijfers[0], cijfers[1] = cijfers[1], cijfers[0]

for i in range(3):
    print(cijfers[i])