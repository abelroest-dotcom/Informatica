import re

invoer = 'John Oudshoorn woont op Hoofdstraat 60D 2678CL DeLier'

patternStraat = r"^[A-Za-z]+$"
straat = invoer.split()[-4]

patternHuisnummer = r"^[1-9]\d{0,2}[A-Za-z]?$"
huisnummer = invoer.split()[-3]

patternPostcode = r"^\d{4}[A-Za-z]{2}$"
postcode = invoer.split()[-2]

patternPlaats = r"^[A-Za-z]+$"
plaats = invoer.split()[-1]

if re.match(patternStraat, straat):
    print(straat, "is geldig")
else:
    print(straat, "is ongeldig")
    
if re.match(patternHuisnummer, huisnummer):
    print(huisnummer, "is geldig")
else:
    print(huisnummer, "is ongeldig")
    
if re.match(patternPostcode, postcode):
    print(postcode, "is geldig")
else:
    print(postcode, "is ongeldig")
    
if re.match(patternPlaats, plaats):
    print(plaats, "is geldig")
else:
    print(plaats, "is ongeldig")