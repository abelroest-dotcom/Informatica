cijfers = []

aantal = int(input("Geef het aantal cijfers: "))

for i in range(aantal):
    cijfer = float(input("Geef een cijfer: "))
    cijfers.append(cijfer)
       
for i in range(aantal):
    for j in range(0, aantal - i - 1):
        if cijfers[j] > cijfers[j + 1]:
            cijfers[j], cijfers[j + 1] = cijfers[j + 1], cijfers[j]

for i in range(aantal):
    print(cijfers[i])