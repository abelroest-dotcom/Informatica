decimaalGetal = int(input("geef een decimaal getal (0 tot en met 255): "))

while not (decimaalGetal>=0 and decimaalGetal<=255):
    decimaalGetal = int(input("geef een decimaal getal (0 tot en met 255): "))
      
binairGetal = ""

while decimaalGetal > 1:

    binairGetal = binairGetal + str(int(decimaalGetal % 2))
    decimaalGetal = int(decimaalGetal / 2)

binairGetal = binairGetal + str(decimaalGetal)

print("".join(reversed(binairGetal)))