import re

invoer = "Jan de Jong woont op Dorpstraat 12 1234AB Amsterdam"

#Meerdere spaties tussen de elementen in het adres worden genegeerd door het splitsen.
adres = " ".join(invoer.split()[-4:])
patternAdres = r"^[A-Za-z]+\s[1-9]\d{0,2}[A-Za-z]?\s\d{4}[A-Za-z]{2}\s[A-Za-z]+$"

if re.match(patternAdres, adres):
    print(adres, "is geldig")
else:
    print(adres, "is ongeldig")

