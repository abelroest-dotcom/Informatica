def decimaalNaarBinair():
    decimaalGetal = int(input("geef een decimaal getal (0 tot en met 255): "))

    binairGetal = ""

    while decimaalGetal > 1:

        binairGetal = binairGetal + str(int(decimaalGetal % 2))
        decimaalGetal = int(decimaalGetal / 2)

    binairGetal = binairGetal + str(decimaalGetal)

    print("".join(reversed(binairGetal)))

def binairNaarDecimaal():
    binairGetal = ""
    decimaalGetal = int(0)

    binairGetal = input("geef een max 8 bits binair getal: ")
    binairGetal = reversed(binairGetal)

    lijst = list(binairGetal)
    aantal = len(lijst) - 1

    for i in range(aantal, -1, -1):
        decimaalGetal = decimaalGetal + int(lijst[i]) * (2 ** i)
        
    print("Het decimale getal is: " + str(decimaalGetal))

keuze = input("geef keuze (0=decimaal naar binair, 1=binair naar decimaal): ")
       
if keuze=="0":
    decimaalNaarBinair()
else:
    binairNaarDecimaal()
