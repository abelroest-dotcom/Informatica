binairGetal = ""
decimaalGetal = int(0)

binairGetal = input("geef een max 8 bits binair getal: ")
binairGetal = reversed(binairGetal)

lijst = list(binairGetal)
aantal = len(lijst) - 1

for i in range(aantal, -1, -1):
    decimaalGetal = decimaalGetal + int(lijst[i]) * (2 ** i)
    
print("Het decimale getal is: " + str(decimaalGetal))
